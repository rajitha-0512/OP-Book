import { useEffect, useState } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { toast } from 'sonner';
import { Plus, UserPlus, MessageSquare, Building2, Edit, Trash2 } from 'lucide-react';

interface Hospital {
  id: string;
  name: string;
  code: string;
  location: string;
  branch: string | null;
  helpline_number: string;
}

interface Doctor {
  id: string;
  name: string;
  degree: string;
  specialization: string;
  fees: number;
  receptionist_contact: string;
}

interface Booking {
  id: string;
  token_number: string;
  patient_name: string;
  patient_mobile: string;
  booking_date: string;
  status: string;
  message: string | null;
  doctors: {
    name: string;
  };
}

const HospitalDashboard = () => {
  const { user } = useAuth();
  const [hospital, setHospital] = useState<Hospital | null>(null);
  const [doctors, setDoctors] = useState<Doctor[]>([]);
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [loading, setLoading] = useState(true);
  const [addDoctorOpen, setAddDoctorOpen] = useState(false);
  const [messageDialogOpen, setMessageDialogOpen] = useState(false);
  const [selectedBooking, setSelectedBooking] = useState<Booking | null>(null);
  const [doctorForm, setDoctorForm] = useState({
    name: '',
    degree: '',
    specialization: '',
    fees: '',
    receptionistContact: '',
  });
  const [messageForm, setMessageForm] = useState({
    status: '',
    message: '',
  });

  useEffect(() => {
    if (user) {
      fetchHospitalData();
    }
  }, [user]);

  const fetchHospitalData = async () => {
    try {
      const { data: hospitalData, error: hospitalError } = await supabase
        .from('hospitals')
        .select('*')
        .eq('user_id', user?.id)
        .single();

      if (hospitalError) throw hospitalError;
      setHospital(hospitalData);

      const [doctorsRes, bookingsRes] = await Promise.all([
        supabase
          .from('doctors')
          .select('*')
          .eq('hospital_id', hospitalData.id)
          .order('name'),
        supabase
          .from('bookings')
          .select(`
            id,
            token_number,
            patient_name,
            patient_mobile,
            booking_date,
            status,
            message,
            doctors (name)
          `)
          .eq('hospital_id', hospitalData.id)
          .order('created_at', { ascending: false })
          .limit(50),
      ]);

      if (doctorsRes.error) throw doctorsRes.error;
      if (bookingsRes.error) throw bookingsRes.error;

      setDoctors(doctorsRes.data || []);
      setBookings(bookingsRes.data as Booking[] || []);
    } catch (error) {
      console.error('Error fetching hospital data:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleAddDoctor = async () => {
    if (!hospital) return;

    try {
      const { error } = await supabase.from('doctors').insert({
        hospital_id: hospital.id,
        name: doctorForm.name,
        degree: doctorForm.degree,
        specialization: doctorForm.specialization,
        fees: parseFloat(doctorForm.fees),
        receptionist_contact: doctorForm.receptionistContact,
      });

      if (error) throw error;

      toast.success('Doctor added successfully!');
      setAddDoctorOpen(false);
      setDoctorForm({ name: '', degree: '', specialization: '', fees: '', receptionistContact: '' });
      fetchHospitalData();
    } catch (error) {
      console.error('Error adding doctor:', error);
      toast.error('Failed to add doctor');
    }
  };

  const handleDeleteDoctor = async (doctorId: string) => {
    try {
      const { error } = await supabase.from('doctors').delete().eq('id', doctorId);
      if (error) throw error;
      toast.success('Doctor removed successfully');
      fetchHospitalData();
    } catch (error) {
      console.error('Error deleting doctor:', error);
      toast.error('Failed to remove doctor');
    }
  };

  const handleSendMessage = async () => {
    if (!selectedBooking) return;

    try {
      const { error } = await supabase
        .from('bookings')
        .update({
          status: messageForm.status as 'successful' | 'delayed' | 'cancelled',
          message: messageForm.message,
        })
        .eq('id', selectedBooking.id);

      if (error) throw error;

      toast.success('Status updated successfully!');
      setMessageDialogOpen(false);
      setSelectedBooking(null);
      setMessageForm({ status: '', message: '' });
      fetchHospitalData();
    } catch (error) {
      console.error('Error updating booking:', error);
      toast.error('Failed to update status');
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'successful':
        return <Badge className="bg-green-500">Successful</Badge>;
      case 'delayed':
        return <Badge className="bg-yellow-500">Delayed</Badge>;
      case 'cancelled':
        return <Badge variant="destructive">Cancelled</Badge>;
      default:
        return <Badge variant="secondary">Pending</Badge>;
    }
  };

  if (loading) {
    return (
      <div className="flex justify-center py-12">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <div className="max-w-6xl mx-auto space-y-8">
      {hospital && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-2xl">
              <Building2 className="h-6 w-6" />
              {hospital.name}
            </CardTitle>
            <CardDescription>
              {hospital.branch && <span>{hospital.branch} • </span>}
              {hospital.location} • Helpline: {hospital.helpline_number}
            </CardDescription>
          </CardHeader>
        </Card>
      )}

      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-semibold">Doctors ({doctors.length})</h2>
        <Dialog open={addDoctorOpen} onOpenChange={setAddDoctorOpen}>
          <DialogTrigger asChild>
            <Button className="gap-2">
              <UserPlus className="h-4 w-4" />
              Add Doctor
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Add New Doctor</DialogTitle>
              <DialogDescription>Add a doctor to your hospital's listing</DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              <div className="space-y-2">
                <Label>Doctor Name</Label>
                <Input
                  placeholder="Dr. John Doe"
                  value={doctorForm.name}
                  onChange={(e) => setDoctorForm({ ...doctorForm, name: e.target.value })}
                />
              </div>
              <div className="space-y-2">
                <Label>Degree</Label>
                <Input
                  placeholder="MBBS, MD"
                  value={doctorForm.degree}
                  onChange={(e) => setDoctorForm({ ...doctorForm, degree: e.target.value })}
                />
              </div>
              <div className="space-y-2">
                <Label>Specialization</Label>
                <Input
                  placeholder="Cardiologist"
                  value={doctorForm.specialization}
                  onChange={(e) => setDoctorForm({ ...doctorForm, specialization: e.target.value })}
                />
              </div>
              <div className="space-y-2">
                <Label>Consultation Fees (₹)</Label>
                <Input
                  type="number"
                  placeholder="500"
                  value={doctorForm.fees}
                  onChange={(e) => setDoctorForm({ ...doctorForm, fees: e.target.value })}
                />
              </div>
              <div className="space-y-2">
                <Label>Receptionist Contact</Label>
                <Input
                  placeholder="10-digit number"
                  value={doctorForm.receptionistContact}
                  onChange={(e) => setDoctorForm({ ...doctorForm, receptionistContact: e.target.value })}
                />
              </div>
              <Button className="w-full" onClick={handleAddDoctor}>
                Add Doctor
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {doctors.length > 0 ? (
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {doctors.map((doctor) => (
            <Card key={doctor.id}>
              <CardHeader className="pb-2">
                <CardTitle className="text-lg">Dr. {doctor.name}</CardTitle>
                <CardDescription>{doctor.specialization}</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-2 text-sm">
                  <p><strong>Degree:</strong> {doctor.degree}</p>
                  <p><strong>Fees:</strong> ₹{doctor.fees}</p>
                  <p><strong>Receptionist:</strong> {doctor.receptionist_contact}</p>
                </div>
                <div className="flex gap-2 mt-4">
                  <Button
                    variant="destructive"
                    size="sm"
                    onClick={() => handleDeleteDoctor(doctor.id)}
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      ) : (
        <Card>
          <CardContent className="py-12 text-center">
            <p className="text-muted-foreground mb-4">No doctors added yet</p>
            <Button onClick={() => setAddDoctorOpen(true)}>Add Your First Doctor</Button>
          </CardContent>
        </Card>
      )}

      <div>
        <h2 className="text-2xl font-semibold mb-4">Recent Bookings</h2>
        {bookings.length > 0 ? (
          <div className="space-y-4">
            {bookings.map((booking) => (
              <Card key={booking.id}>
                <CardContent className="pt-6">
                  <div className="flex flex-col md:flex-row justify-between gap-4">
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <h3 className="font-semibold">{booking.patient_name}</h3>
                        {getStatusBadge(booking.status)}
                      </div>
                      <p className="text-sm text-muted-foreground">
                        Doctor: Dr. {booking.doctors.name}
                      </p>
                      <p className="text-sm text-muted-foreground">
                        Mobile: {booking.patient_mobile}
                      </p>
                      {booking.message && (
                        <p className="text-sm bg-accent p-2 rounded mt-2">
                          {booking.message}
                        </p>
                      )}
                    </div>
                    <div className="flex flex-col items-end gap-2">
                      <p className="font-bold text-primary">{booking.token_number}</p>
                      <p className="text-sm text-muted-foreground">
                        {new Date(booking.booking_date).toLocaleDateString()}
                      </p>
                      <Dialog open={messageDialogOpen && selectedBooking?.id === booking.id} onOpenChange={(open) => {
                        setMessageDialogOpen(open);
                        if (open) {
                          setSelectedBooking(booking);
                          setMessageForm({ status: booking.status, message: booking.message || '' });
                        }
                      }}>
                        <DialogTrigger asChild>
                          <Button variant="outline" size="sm" className="gap-2">
                            <MessageSquare className="h-4 w-4" />
                            Send Message
                          </Button>
                        </DialogTrigger>
                        <DialogContent>
                          <DialogHeader>
                            <DialogTitle>Update Booking Status</DialogTitle>
                            <DialogDescription>
                              Send a message to patient: {booking.patient_name}
                            </DialogDescription>
                          </DialogHeader>
                          <div className="space-y-4">
                            <div className="space-y-2">
                              <Label>Status</Label>
                              <Select
                                value={messageForm.status}
                                onValueChange={(value) => setMessageForm({ ...messageForm, status: value })}
                              >
                                <SelectTrigger>
                                  <SelectValue placeholder="Select status" />
                                </SelectTrigger>
                                <SelectContent>
                                  <SelectItem value="successful">Successful</SelectItem>
                                  <SelectItem value="delayed">Delayed</SelectItem>
                                  <SelectItem value="cancelled">Cancelled</SelectItem>
                                </SelectContent>
                              </Select>
                            </div>
                            <div className="space-y-2">
                              <Label>Message (Optional)</Label>
                              <Textarea
                                placeholder="Add a message for the patient..."
                                value={messageForm.message}
                                onChange={(e) => setMessageForm({ ...messageForm, message: e.target.value })}
                              />
                            </div>
                            <Button className="w-full" onClick={handleSendMessage}>
                              Update Status
                            </Button>
                          </div>
                        </DialogContent>
                      </Dialog>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : (
          <Card>
            <CardContent className="py-12 text-center">
              <p className="text-muted-foreground">No bookings yet</p>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
};

export default HospitalDashboard;
