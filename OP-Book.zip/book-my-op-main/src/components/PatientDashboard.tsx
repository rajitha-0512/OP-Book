import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { CalendarPlus, Calendar, User, MapPin } from 'lucide-react';

interface Booking {
  id: string;
  token_number: string;
  patient_name: string;
  booking_date: string;
  status: string;
  amount: number;
  message: string | null;
  doctors: {
    name: string;
    specialization: string;
  };
  hospitals: {
    name: string;
    location: string;
  };
}

interface Patient {
  name: string;
  age: number;
  gender: string;
  mobile_no: string;
}

const PatientDashboard = () => {
  const { user } = useAuth();
  const [patient, setPatient] = useState<Patient | null>(null);
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (user) {
      fetchPatientData();
    }
  }, [user]);

  const fetchPatientData = async () => {
    try {
      const { data: patientData, error: patientError } = await supabase
        .from('patients')
        .select('name, age, gender, mobile_no')
        .eq('user_id', user?.id)
        .single();

      if (patientError) throw patientError;
      setPatient(patientData);

      // Fetch bookings with related data
      const { data: patientRecord } = await supabase
        .from('patients')
        .select('id')
        .eq('user_id', user?.id)
        .single();

      if (patientRecord) {
        const { data: bookingsData, error: bookingsError } = await supabase
          .from('bookings')
          .select(`
            id,
            token_number,
            patient_name,
            booking_date,
            status,
            amount,
            message,
            doctors (name, specialization),
            hospitals (name, location)
          `)
          .eq('patient_id', patientRecord.id)
          .order('created_at', { ascending: false });

        if (bookingsError) throw bookingsError;
        setBookings(bookingsData as Booking[] || []);
      }
    } catch (error) {
      console.error('Error fetching patient data:', error);
    } finally {
      setLoading(false);
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'successful':
        return <Badge className="bg-green-500">Successful</Badge>;
      case 'delayed':
        return <Badge className="bg-yellow-500">Delayed</Badge>;
      case 'cancelled':
        return <Badge variant="destructive">Cancelled</Badge>;
      default:
        return <Badge variant="secondary">Pending</Badge>;
    }
  };

  if (loading) {
    return (
      <div className="flex justify-center py-12">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto space-y-8">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold text-primary">
            Welcome, {patient?.name || 'Patient'}!
          </h1>
          <p className="text-muted-foreground">Manage your appointments here</p>
        </div>
        <Link to="/search-hospitals">
          <Button className="gap-2">
            <CalendarPlus className="h-4 w-4" />
            Book New Appointment
          </Button>
        </Link>
      </div>

      {patient && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <User className="h-5 w-5" />
              Your Profile
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div>
                <p className="text-sm text-muted-foreground">Name</p>
                <p className="font-medium">{patient.name}</p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Age</p>
                <p className="font-medium">{patient.age} years</p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Gender</p>
                <p className="font-medium capitalize">{patient.gender}</p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Mobile</p>
                <p className="font-medium">{patient.mobile_no}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      <div>
        <h2 className="text-2xl font-semibold mb-4 flex items-center gap-2">
          <Calendar className="h-6 w-6" />
          Booking History
        </h2>

        {bookings.length > 0 ? (
          <div className="space-y-4">
            {bookings.map((booking) => (
              <Card key={booking.id}>
                <CardContent className="pt-6">
                  <div className="flex flex-col md:flex-row justify-between gap-4">
                    <div className="space-y-2">
                      <div className="flex items-center gap-2">
                        <h3 className="font-semibold text-lg">{booking.hospitals.name}</h3>
                        {getStatusBadge(booking.status)}
                      </div>
                      <p className="text-muted-foreground">
                        Dr. {booking.doctors.name} - {booking.doctors.specialization}
                      </p>
                      <div className="flex items-center gap-2 text-sm text-muted-foreground">
                        <MapPin className="h-4 w-4" />
                        {booking.hospitals.location}
                      </div>
                      {booking.message && (
                        <p className="text-sm bg-accent p-2 rounded">
                          <strong>Message:</strong> {booking.message}
                        </p>
                      )}
                    </div>
                    <div className="text-right space-y-1">
                      <p className="text-sm text-muted-foreground">Token</p>
                      <p className="font-bold text-primary text-lg">{booking.token_number}</p>
                      <p className="text-sm text-muted-foreground">
                        {new Date(booking.booking_date).toLocaleDateString()}
                      </p>
                      <p className="font-semibold">₹{booking.amount}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : (
          <Card>
            <CardContent className="py-12 text-center">
              <p className="text-muted-foreground mb-4">No bookings found</p>
              <Link to="/search-hospitals">
                <Button>Book Your First Appointment</Button>
              </Link>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
};

export default PatientDashboard;
