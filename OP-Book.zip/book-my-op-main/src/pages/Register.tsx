import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { User, Building2 } from 'lucide-react';
import BackButton from '@/components/BackButton';

const Register = () => {
  return (
    <div className="min-h-screen flex items-center justify-center bg-background px-4 relative">
      <BackButton to="/" />
      
      <Card className="w-full max-w-lg">
        <CardHeader className="text-center">
          <CardTitle className="text-3xl font-bold text-primary">Register</CardTitle>
          <CardDescription className="text-lg">
            Choose how you want to register
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="grid gap-6">
            <Link to="/register/patient">
              <Button 
                variant="outline" 
                className="w-full h-24 text-lg font-semibold gap-4 border-2 hover:bg-primary hover:text-primary-foreground hover:border-primary transition-all"
              >
                <User className="h-8 w-8" />
                Register as Patient
              </Button>
            </Link>
            
            <Link to="/register/hospital">
              <Button 
                variant="outline" 
                className="w-full h-24 text-lg font-semibold gap-4 border-2 hover:bg-primary hover:text-primary-foreground hover:border-primary transition-all"
              >
                <Building2 className="h-8 w-8" />
                Register as Hospital
              </Button>
            </Link>
          </div>

          <p className="text-center text-muted-foreground">
            Already have an account?{' '}
            <Link to="/auth" className="text-primary font-semibold hover:underline">
              Login here
            </Link>
          </p>
        </CardContent>
      </Card>
    </div>
  );
};

export default Register;
