import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { CalendarPlus, UserPlus } from 'lucide-react';
import Header from '@/components/Header';

const Index = () => {
  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Header />
      
      <main className="flex-1 flex items-center justify-center px-4">
        <div className="max-w-2xl w-full text-center space-y-12">
          <div className="space-y-4">
            <h1 className="text-5xl md:text-6xl font-bold text-primary">
              OP Book
            </h1>
            <p className="text-xl text-muted-foreground">
              Your trusted platform for booking outpatient appointments
            </p>
          </div>

          <div className="flex flex-col sm:flex-row gap-6 justify-center">
            <Link to="/search-hospitals" className="flex-1 max-w-sm">
              <Button 
                size="lg" 
                className="w-full h-32 text-xl font-bold gap-4 shadow-lg hover:shadow-xl transition-all"
              >
                <CalendarPlus className="h-8 w-8" />
                <span className="text-center leading-tight">
                  Do You Want to<br />Book Your OP Now?
                </span>
              </Button>
            </Link>

            <Link to="/register" className="flex-1 max-w-sm">
              <Button 
                size="lg" 
                variant="outline"
                className="w-full h-32 text-xl font-bold gap-4 shadow-lg hover:shadow-xl transition-all border-2 border-primary text-primary hover:bg-primary hover:text-primary-foreground"
              >
                <UserPlus className="h-8 w-8" />
                <span>Register Now</span>
              </Button>
            </Link>
          </div>

          <p className="text-muted-foreground">
            Already have an account?{' '}
            <Link to="/auth" className="text-primary font-semibold hover:underline">
              Login here
            </Link>
          </p>
        </div>
      </main>

      <footer className="py-6 text-center text-muted-foreground border-t">
        <p>© 2024 OP Book. All rights reserved.</p>
      </footer>
    </div>
  );
};

export default Index;
