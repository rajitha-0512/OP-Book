import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { supabase } from '@/integrations/supabase/client';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { MapPin, Phone, GraduationCap, Stethoscope, IndianRupee } from 'lucide-react';
import BackButton from '@/components/BackButton';
import Header from '@/components/Header';

interface Hospital {
  id: string;
  name: string;
  location: string;
  branch: string | null;
  helpline_number: string;
}

interface Doctor {
  id: string;
  name: string;
  degree: string;
  specialization: string;
  fees: number;
  receptionist_contact: string;
}

const HospitalDetails = () => {
  const { hospitalId } = useParams();
  const navigate = useNavigate();
  const [hospital, setHospital] = useState<Hospital | null>(null);
  const [doctors, setDoctors] = useState<Doctor[]>([]);
  const [selectedDoctor, setSelectedDoctor] = useState<string>('');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (hospitalId) {
      fetchHospitalDetails();
    }
  }, [hospitalId]);

  const fetchHospitalDetails = async () => {
    try {
      const [hospitalRes, doctorsRes] = await Promise.all([
        supabase.from('hospitals').select('*').eq('id', hospitalId).single(),
        supabase.from('doctors').select('*').eq('hospital_id', hospitalId).order('name'),
      ]);

      if (hospitalRes.error) throw hospitalRes.error;
      if (doctorsRes.error) throw doctorsRes.error;

      setHospital(hospitalRes.data);
      setDoctors(doctorsRes.data || []);
    } catch (error) {
      console.error('Error fetching hospital details:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleBookAppointment = () => {
    if (selectedDoctor) {
      navigate(`/book/${hospitalId}/${selectedDoctor}`);
    }
  };

  const selectedDoctorDetails = doctors.find((d) => d.id === selectedDoctor);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }

  if (!hospital) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <p className="text-muted-foreground">Hospital not found</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <div className="container mx-auto px-4 py-8 relative">
        <BackButton to="/search-hospitals" />
        
        <div className="max-w-4xl mx-auto pt-8">
          <div className="text-center mb-8">
            <h1 className="text-4xl md:text-5xl font-bold text-primary mb-4">
              {hospital.name}
            </h1>
            {hospital.branch && (
              <p className="text-xl text-muted-foreground mb-2">{hospital.branch}</p>
            )}
            <div className="flex items-center justify-center gap-2 text-lg text-muted-foreground">
              <MapPin className="h-5 w-5" />
              <span>{hospital.location}</span>
            </div>
          </div>

          <Card className="mb-8">
            <CardHeader>
              <CardTitle>Select a Doctor</CardTitle>
              <CardDescription>Choose a doctor to book your appointment</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              {doctors.length > 0 ? (
                <>
                  <Select value={selectedDoctor} onValueChange={setSelectedDoctor}>
                    <SelectTrigger className="h-14 text-lg">
                      <SelectValue placeholder="Select a doctor" />
                    </SelectTrigger>
                    <SelectContent>
                      {doctors.map((doctor) => (
                        <SelectItem key={doctor.id} value={doctor.id}>
                          <div className="flex items-center gap-2">
                            <span className="font-medium">{doctor.name}</span>
                            <span className="text-muted-foreground">- {doctor.specialization}</span>
                          </div>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>

                  {selectedDoctorDetails && (
                    <Card className="bg-accent/50">
                      <CardContent className="pt-6">
                        <div className="space-y-4">
                          <h3 className="text-xl font-bold text-primary">
                            Dr. {selectedDoctorDetails.name}
                          </h3>
                          
                          <div className="grid gap-3">
                            <div className="flex items-center gap-3">
                              <GraduationCap className="h-5 w-5 text-primary" />
                              <span>{selectedDoctorDetails.degree}</span>
                            </div>
                            <div className="flex items-center gap-3">
                              <Stethoscope className="h-5 w-5 text-primary" />
                              <span>{selectedDoctorDetails.specialization}</span>
                            </div>
                            <div className="flex items-center gap-3">
                              <IndianRupee className="h-5 w-5 text-primary" />
                              <span className="font-semibold">₹{selectedDoctorDetails.fees}</span>
                            </div>
                            <div className="flex items-center gap-3">
                              <Phone className="h-5 w-5 text-primary" />
                              <span>Receptionist: {selectedDoctorDetails.receptionist_contact}</span>
                            </div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  )}

                  <Button 
                    size="lg" 
                    className="w-full h-14 text-lg"
                    disabled={!selectedDoctor}
                    onClick={handleBookAppointment}
                  >
                    Book Appointment
                  </Button>
                </>
              ) : (
                <p className="text-center text-muted-foreground py-8">
                  No doctors available at this hospital yet.
                </p>
              )}
            </CardContent>
          </Card>

          <div className="text-center text-muted-foreground">
            <p className="flex items-center justify-center gap-2">
              <Phone className="h-4 w-4" />
              Helpline: {hospital.helpline_number}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default HospitalDetails;
