import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Phone, QrCode } from 'lucide-react';
import { toast } from 'sonner';
import BackButton from '@/components/BackButton';
import Header from '@/components/Header';

interface BookingData {
  hospitalId: string;
  doctorId: string;
  hospitalName: string;
  doctorName: string;
  doctorSpecialization: string;
  amount: number;
  patientName: string;
  patientAge: number;
  patientGender: string;
  patientMobile: string;
}

const Payment = () => {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [bookingData, setBookingData] = useState<BookingData | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);

  useEffect(() => {
    const data = sessionStorage.getItem('bookingData');
    if (data) {
      setBookingData(JSON.parse(data));
    } else {
      navigate('/search-hospitals');
    }
  }, [navigate]);

  const generateTokenNumber = () => {
    const date = new Date().toISOString().slice(0, 10).replace(/-/g, '');
    const random = Math.floor(Math.random() * 1000).toString().padStart(3, '0');
    return `OP${date}${random}`;
  };

  const handlePayment = async () => {
    if (!bookingData) return;

    setIsProcessing(true);

    try {
      // Get or create patient record
      let patientId: string | null = null;

      if (user) {
        const { data: patientData } = await supabase
          .from('patients')
          .select('id')
          .eq('user_id', user.id)
          .single();

        if (patientData) {
          patientId = patientData.id;
        }
      }

      // If no patient record exists, we'll create a temporary one
      if (!patientId && user) {
        const { data: newPatient, error: createError } = await supabase
          .from('patients')
          .insert({
            user_id: user.id,
            name: bookingData.patientName,
            age: bookingData.patientAge,
            gender: bookingData.patientGender,
            mobile_no: bookingData.patientMobile,
          })
          .select('id')
          .single();

        if (createError) throw createError;
        patientId = newPatient.id;
      }

      if (!patientId) {
        toast.error('Please login to complete booking');
        navigate('/auth');
        return;
      }

      const tokenNumber = generateTokenNumber();

      const { error: bookingError } = await supabase.from('bookings').insert({
        patient_id: patientId,
        doctor_id: bookingData.doctorId,
        hospital_id: bookingData.hospitalId,
        patient_name: bookingData.patientName,
        patient_age: bookingData.patientAge,
        patient_gender: bookingData.patientGender,
        patient_mobile: bookingData.patientMobile,
        amount: bookingData.amount,
        token_number: tokenNumber,
        status: 'successful',
      });

      if (bookingError) throw bookingError;

      // Store success data and navigate
      sessionStorage.setItem('paymentSuccess', JSON.stringify({
        ...bookingData,
        tokenNumber,
      }));
      sessionStorage.removeItem('bookingData');

      navigate('/payment-success');
    } catch (error) {
      console.error('Error processing payment:', error);
      toast.error('Failed to process payment. Please try again.');
    } finally {
      setIsProcessing(false);
    }
  };

  if (!bookingData) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <div className="container mx-auto px-4 py-8 relative">
        <BackButton to={`/book/${bookingData.hospitalId}/${bookingData.doctorId}`} />
        
        <div className="max-w-md mx-auto pt-8">
          <Card>
            <CardHeader className="text-center">
              <CardTitle className="text-2xl font-bold text-primary">Payment</CardTitle>
              <CardDescription>Scan the QR code to complete payment</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="bg-accent/50 p-4 rounded-lg space-y-2">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Hospital:</span>
                  <span className="font-medium">{bookingData.hospitalName}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Doctor:</span>
                  <span className="font-medium">Dr. {bookingData.doctorName}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Patient:</span>
                  <span className="font-medium">{bookingData.patientName}</span>
                </div>
                <div className="flex justify-between border-t pt-2 mt-2">
                  <span className="font-semibold">Total Amount:</span>
                  <span className="font-bold text-primary text-xl">₹{bookingData.amount}</span>
                </div>
              </div>

              <div className="flex flex-col items-center space-y-4">
                <div className="bg-card border-2 border-dashed border-primary/30 p-8 rounded-lg">
                  <QrCode className="h-32 w-32 text-primary" />
                </div>
                <p className="text-sm text-muted-foreground text-center">
                  Scan this QR code with any UPI app to pay
                </p>
              </div>

              <Button 
                size="lg" 
                className="w-full"
                onClick={handlePayment}
                disabled={isProcessing}
              >
                {isProcessing ? 'Processing...' : 'Confirm Payment'}
              </Button>

              <div className="text-center pt-4 border-t">
                <p className="text-sm text-muted-foreground flex items-center justify-center gap-2">
                  <Phone className="h-4 w-4" />
                  Helpline: 1800-XXX-XXXX
                </p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default Payment;
