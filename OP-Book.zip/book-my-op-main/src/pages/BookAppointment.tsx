import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { supabase } from '@/integrations/supabase/client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { toast } from 'sonner';
import BackButton from '@/components/BackButton';
import Header from '@/components/Header';
import { z } from 'zod';

const bookingSchema = z.object({
  patientName: z.string().min(2, 'Name must be at least 2 characters'),
  patientAge: z.number().min(1, 'Age must be at least 1').max(150, 'Please enter a valid age'),
  patientGender: z.string().min(1, 'Please select a gender'),
  patientMobile: z.string().regex(/^\d{10}$/, 'Please enter a valid 10-digit mobile number'),
});

interface Doctor {
  id: string;
  name: string;
  fees: number;
  specialization: string;
}

interface Hospital {
  id: string;
  name: string;
}

const BookAppointment = () => {
  const { hospitalId, doctorId } = useParams();
  const navigate = useNavigate();
  const [doctor, setDoctor] = useState<Doctor | null>(null);
  const [hospital, setHospital] = useState<Hospital | null>(null);
  const [loading, setLoading] = useState(true);
  const [formData, setFormData] = useState({
    patientName: '',
    patientAge: '',
    patientGender: '',
    patientMobile: '',
  });

  useEffect(() => {
    if (hospitalId && doctorId) {
      fetchDetails();
    }
  }, [hospitalId, doctorId]);

  const fetchDetails = async () => {
    try {
      const [hospitalRes, doctorRes] = await Promise.all([
        supabase.from('hospitals').select('id, name').eq('id', hospitalId).single(),
        supabase.from('doctors').select('id, name, fees, specialization').eq('id', doctorId).single(),
      ]);

      if (hospitalRes.error) throw hospitalRes.error;
      if (doctorRes.error) throw doctorRes.error;

      setHospital(hospitalRes.data);
      setDoctor(doctorRes.data);
    } catch (error) {
      console.error('Error fetching details:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    try {
      bookingSchema.parse({
        ...formData,
        patientAge: parseInt(formData.patientAge),
      });

      // Store booking data in sessionStorage for payment page
      sessionStorage.setItem('bookingData', JSON.stringify({
        hospitalId,
        doctorId,
        hospitalName: hospital?.name,
        doctorName: doctor?.name,
        doctorSpecialization: doctor?.specialization,
        amount: doctor?.fees,
        ...formData,
        patientAge: parseInt(formData.patientAge),
      }));

      navigate('/payment');
    } catch (error) {
      if (error instanceof z.ZodError) {
        toast.error(error.errors[0].message);
      }
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <div className="container mx-auto px-4 py-8 relative">
        <BackButton to={`/hospital/${hospitalId}`} />
        
        <div className="max-w-md mx-auto pt-8">
          <Card>
            <CardHeader className="text-center">
              <CardTitle className="text-2xl font-bold text-primary">Book Appointment</CardTitle>
              <CardDescription>
                <span className="block font-medium text-foreground">{hospital?.name}</span>
                <span className="block">Dr. {doctor?.name} - {doctor?.specialization}</span>
                <span className="block font-semibold text-primary mt-2">Fees: ₹{doctor?.fees}</span>
              </CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="patientName">Patient Name</Label>
                  <Input
                    id="patientName"
                    placeholder="Enter patient's full name"
                    value={formData.patientName}
                    onChange={(e) => setFormData({ ...formData, patientName: e.target.value })}
                    required
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="patientAge">Age</Label>
                    <Input
                      id="patientAge"
                      type="number"
                      placeholder="Age"
                      value={formData.patientAge}
                      onChange={(e) => setFormData({ ...formData, patientAge: e.target.value })}
                      required
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="patientGender">Gender</Label>
                    <Select 
                      value={formData.patientGender} 
                      onValueChange={(value) => setFormData({ ...formData, patientGender: value })}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="male">Male</SelectItem>
                        <SelectItem value="female">Female</SelectItem>
                        <SelectItem value="other">Other</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="patientMobile">Mobile Number</Label>
                  <Input
                    id="patientMobile"
                    placeholder="10-digit mobile number"
                    value={formData.patientMobile}
                    onChange={(e) => setFormData({ ...formData, patientMobile: e.target.value })}
                    required
                  />
                </div>

                <Button type="submit" className="w-full" size="lg">
                  Proceed to Payment
                </Button>
              </form>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default BookAppointment;
