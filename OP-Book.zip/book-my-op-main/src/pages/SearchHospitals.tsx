import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { supabase } from '@/integrations/supabase/client';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Search, MapPin, Building2 } from 'lucide-react';
import BackButton from '@/components/BackButton';
import Header from '@/components/Header';

interface Hospital {
  id: string;
  name: string;
  location: string;
  branch: string | null;
  is_featured: boolean;
}

const SearchHospitals = () => {
  const [searchQuery, setSearchQuery] = useState('');
  const [hospitals, setHospitals] = useState<Hospital[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchHospitals();
  }, []);

  const fetchHospitals = async () => {
    try {
      const { data, error } = await supabase
        .from('hospitals')
        .select('id, name, location, branch, is_featured')
        .order('is_featured', { ascending: false })
        .order('name');

      if (error) throw error;
      setHospitals(data || []);
    } catch (error) {
      console.error('Error fetching hospitals:', error);
    } finally {
      setLoading(false);
    }
  };

  const filteredHospitals = hospitals.filter((hospital) =>
    hospital.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    hospital.location.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const featuredHospitals = filteredHospitals.filter((h) => h.is_featured);
  const otherHospitals = filteredHospitals.filter((h) => !h.is_featured);

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <div className="container mx-auto px-4 py-8 relative">
        <BackButton to="/" />
        
        <div className="max-w-4xl mx-auto pt-8">
          <div className="text-center mb-8">
            <h1 className="text-4xl font-bold text-primary mb-2">Find Hospitals</h1>
            <p className="text-muted-foreground">Search and select a hospital to book your OP</p>
          </div>

          <div className="relative mb-8">
            <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 h-5 w-5 text-muted-foreground" />
            <Input
              type="text"
              placeholder="Search hospitals by name or location..."
              className="pl-12 h-14 text-lg"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>

          {loading ? (
            <div className="flex justify-center py-12">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
            </div>
          ) : (
            <div className="space-y-8">
              {featuredHospitals.length > 0 && (
                <div>
                  <h2 className="text-2xl font-semibold mb-4 flex items-center gap-2">
                    <Building2 className="h-6 w-6 text-primary" />
                    Top Hospitals
                  </h2>
                  <div className="grid gap-4 md:grid-cols-2">
                    {featuredHospitals.map((hospital) => (
                      <Link key={hospital.id} to={`/hospital/${hospital.id}`}>
                        <Card className="hover:shadow-lg transition-shadow cursor-pointer border-2 border-primary/20 hover:border-primary">
                          <CardHeader>
                            <CardTitle className="text-primary">{hospital.name}</CardTitle>
                            {hospital.branch && (
                              <CardDescription className="text-sm">{hospital.branch}</CardDescription>
                            )}
                          </CardHeader>
                          <CardContent>
                            <div className="flex items-center gap-2 text-muted-foreground">
                              <MapPin className="h-4 w-4" />
                              <span>{hospital.location}</span>
                            </div>
                          </CardContent>
                        </Card>
                      </Link>
                    ))}
                  </div>
                </div>
              )}

              <div>
                <h2 className="text-2xl font-semibold mb-4">
                  {featuredHospitals.length > 0 ? 'All Hospitals' : 'Hospitals'}
                </h2>
                {otherHospitals.length > 0 ? (
                  <div className="grid gap-4 md:grid-cols-2">
                    {otherHospitals.map((hospital) => (
                      <Link key={hospital.id} to={`/hospital/${hospital.id}`}>
                        <Card className="hover:shadow-lg transition-shadow cursor-pointer hover:border-primary">
                          <CardHeader>
                            <CardTitle>{hospital.name}</CardTitle>
                            {hospital.branch && (
                              <CardDescription className="text-sm">{hospital.branch}</CardDescription>
                            )}
                          </CardHeader>
                          <CardContent>
                            <div className="flex items-center gap-2 text-muted-foreground">
                              <MapPin className="h-4 w-4" />
                              <span>{hospital.location}</span>
                            </div>
                          </CardContent>
                        </Card>
                      </Link>
                    ))}
                  </div>
                ) : (
                  <p className="text-center text-muted-foreground py-8">
                    {searchQuery ? 'No hospitals found matching your search.' : 'No hospitals available yet.'}
                  </p>
                )}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default SearchHospitals;
