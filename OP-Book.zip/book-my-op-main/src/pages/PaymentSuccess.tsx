import { useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { CheckCircle } from 'lucide-react';
import Header from '@/components/Header';

interface SuccessData {
  hospitalName: string;
  doctorName: string;
  patientName: string;
  amount: number;
  tokenNumber: string;
}

const PaymentSuccess = () => {
  const navigate = useNavigate();
  const [successData, setSuccessData] = useState<SuccessData | null>(null);

  useEffect(() => {
    const data = sessionStorage.getItem('paymentSuccess');
    if (data) {
      setSuccessData(JSON.parse(data));
      sessionStorage.removeItem('paymentSuccess');
    } else {
      navigate('/');
    }
  }, [navigate]);

  if (!successData) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <div className="container mx-auto px-4 py-8">
        <div className="max-w-md mx-auto pt-8">
          <Card className="border-green-500/50">
            <CardHeader className="text-center pb-2">
              <div className="flex justify-center mb-4">
                <CheckCircle className="h-20 w-20 text-green-500" />
              </div>
              <CardTitle className="text-3xl font-bold text-green-600">
                Payment Successful!
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="bg-green-50 dark:bg-green-900/20 p-4 rounded-lg text-center">
                <p className="text-sm text-muted-foreground mb-1">Your Token Number</p>
                <p className="text-3xl font-bold text-primary">{successData.tokenNumber}</p>
              </div>

              <div className="bg-accent/50 p-4 rounded-lg space-y-2">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Hospital:</span>
                  <span className="font-medium">{successData.hospitalName}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Doctor:</span>
                  <span className="font-medium">Dr. {successData.doctorName}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Patient:</span>
                  <span className="font-medium">{successData.patientName}</span>
                </div>
                <div className="flex justify-between border-t pt-2 mt-2">
                  <span className="font-semibold">Amount Paid:</span>
                  <span className="font-bold text-primary">₹{successData.amount}</span>
                </div>
              </div>

              <p className="text-center text-sm text-muted-foreground">
                Please save your token number for reference at the hospital
              </p>

              <div className="flex flex-col gap-3">
                <Link to="/">
                  <Button className="w-full" size="lg">
                    Go to Home
                  </Button>
                </Link>
                <Link to="/dashboard">
                  <Button variant="outline" className="w-full" size="lg">
                    View Booking History
                  </Button>
                </Link>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default PaymentSuccess;
